﻿namespace $safeprojectname$.Utilities
{
    public static class Regexs
    {
    }
}
