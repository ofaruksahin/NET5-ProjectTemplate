﻿namespace $safeprojectname$.Utilities
{
    public static class Messages
    {
        public static string Successful => "Successful";
        public static string Error => "Error";
    }
}
