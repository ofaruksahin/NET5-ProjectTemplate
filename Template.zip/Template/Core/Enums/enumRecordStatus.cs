﻿namespace $safeprojectname$.Enums
{
    public enum enumRecordStatus
    {
        InActive,
        Active
    }
}
