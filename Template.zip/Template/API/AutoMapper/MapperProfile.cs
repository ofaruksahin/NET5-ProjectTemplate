﻿using AutoMapper;

namespace $safeprojectname$.AutoMapper
{
    public class MapperProfile : Profile
    {
    }
}
